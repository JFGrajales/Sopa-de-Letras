//palabra JavaScript color rojo
function comprobar1(){
	a1 = document.getElementById('celda1').style.background="red";
 
}
function comprobar2(){
	a1 = document.getElementById('celda2').style.background="red";
}
function comprobar3(){
	a1 = document.getElementById('celda3').style.background="red";
}
//Va compartida con palabra apache
function comprobar4(){
	a1 = document.getElementById('celda4').style.background="blue";
}
function comprobar5(){
	a1 = document.getElementById('celda5').style.background="red";
}
function comprobar6(){
	a1 = document.getElementById('celda6').style.background="red";
}
function comprobar7(){
	a1 = document.getElementById('celda7').style.background="red";
}
function comprobar8(){
	a1 = document.getElementById('celda8').style.background="red";
}
function comprobar9(){
	a1 = document.getElementById('celda9').style.background="red";
}
function comprobar10(){
	a1 = document.getElementById('celda10').style.background="red";
}

//parte de software
function comprobar11(){
	a1 = document.getElementById('celda11').style.background="yellow";
}

//parte de div
function comprobar14(){
	a1 = document.getElementById('celda14').style.background="red";
}

//parte de frontend
function comprobar16(){
	a1 = document.getElementById('celda16').style.background="purple";
}

//parte de head
function comprobar18(){
	a1 = document.getElementById('celda18').style.background="blue";
}

//parte de apache
function comprobar26(){
	a1 = document.getElementById('celda26').style.background="blue";
}

//HTML en naranja
function comprobar28(){
	a1 = document.getElementById('celda28').style.background="orange";
}
function comprobar29(){
	a1 = document.getElementById('celda29').style.background="orange";
}
function comprobar30(){
	a1 = document.getElementById('celda30').style.background="orange";
}
function comprobar31(){
	a1 = document.getElementById('celda31').style.background="orange";
}

//parte de software
function comprobar32(){
	a1 = document.getElementById('celda32').style.background="yellow";
}

//parte de div
function comprobar35(){
	a1 = document.getElementById('celda35').style.background="red";
}

//parte de frontend
function comprobar37(){
	a1 = document.getElementById('celda37').style.background="purple";
}

//parte de head
function comprobar40(){
	a1 = document.getElementById('celda40').style.background="blue";
}

//parte de class
function comprobar44(){
	a1 = document.getElementById('celda44').style.background="purple";
}

//parte de apache
function comprobar48(){
	a1 = document.getElementById('celda48').style.background="blue";
}

//parte de php
function comprobar52(){
	a1 = document.getElementById('celda52').style.background="green";
}
//parte de software
function comprobar53(){
	a1 = document.getElementById('celda53').style.background="yellow";
}
//parte de cache
function comprobar54(){
	a1 = document.getElementById('celda54').style.background="teal";
}
//parte de div
function comprobar56(){
	a1 = document.getElementById('celda56').style.background="red";
}

//parte de frontend
function comprobar58(){
	a1 = document.getElementById('celda58').style.background="purple";
}
//parte de head
function comprobar62(){
	a1 = document.getElementById('celda62').style.background="blue";
}

//parte de class
function comprobar65(){
	a1 = document.getElementById('celda65').style.background="purple";
}

//parte de apache
function comprobar70(){
	a1 = document.getElementById('celda70').style.background="blue";
}

//parte de php
function comprobar73(){
	a1 = document.getElementById('celda73').style.background="green";
}

//parte de software
function comprobar74(){
	a1 = document.getElementById('celda74').style.background="yellow";
}
//parte de cache
function comprobar75(){
	a1 = document.getElementById('celda75').style.background="teal";
}
//parte de frontend
function comprobar79(){
	a1 = document.getElementById('celda79').style.background="purple";
}
//parte de head
function comprobar84(){
	a1 = document.getElementById('celda84').style.background="blue";
}
//parte de class
function comprobar86(){
	a1 = document.getElementById('celda86').style.background="purple";
}
//body en azul claro
function comprobar87(){
	a1 = document.getElementById('celda87').style.background="aqua";
}
function comprobar88(){
	a1 = document.getElementById('celda88').style.background="aqua";
}
function comprobar89(){
	a1 = document.getElementById('celda89').style.background="aqua";
}
function comprobar90(){
	a1 = document.getElementById('celda90').style.background="aqua";
}

//parte de apache
function comprobar92(){
	a1 = document.getElementById('celda92').style.background="blue";
}

//parte de php
function comprobar94(){
	a1 = document.getElementById('celda94').style.background="green";
}

//parte de software
function comprobar95(){
	a1 = document.getElementById('celda95').style.background="yellow";
}

//parte de cache
function comprobar96(){
	a1 = document.getElementById('celda96').style.background="teal";
}

//parte de frontend
function comprobar100(){
	a1 = document.getElementById('celda100').style.background="purple";
}

//email en verde
function comprobar101(){
	a1 = document.getElementById('celda101').style.background="green";
}
function comprobar102(){
	a1 = document.getElementById('celda102').style.background="green";
}
function comprobar103(){
	a1 = document.getElementById('celda103').style.background="green";
}
function comprobar104(){
	a1 = document.getElementById('celda104').style.background="green";
}
function comprobar105(){
	a1 = document.getElementById('celda105').style.background="green";
}

//parte de class
function comprobar107(){
	a1 = document.getElementById('celda107').style.background="purple";
}

//parte de apache
function comprobar114(){
	a1 = document.getElementById('celda114').style.background="blue";
}
//parte de software
function comprobar116(){
	a1 = document.getElementById('celda116').style.background="yellow";
}
//parte de cache
function comprobar117(){
	a1 = document.getElementById('celda117').style.background="teal";
}

//parte de frontend
function comprobar121(){
	a1 = document.getElementById('celda121').style.background="purple";
}
//parte de frame
function comprobar123(){
	a1 = document.getElementById('celda123').style.background="grey";
}
//parte de class
function comprobar128(){
	a1 = document.getElementById('celda128').style.background="purple";
}
//parte de software
function comprobar137(){
	a1 = document.getElementById('celda137').style.background="yellow";
}
//parte de cache
function comprobar138(){
	a1 = document.getElementById('celda138').style.background="teal";
}
//parte de css
function comprobar139(){
	a1 = document.getElementById('celda139').style.background="rgba(82, 136, 224 )";
}
//parte de frontend
function comprobar142(){
	a1 = document.getElementById('celda142').style.background="purple";
}
//parte de frame
function comprobar144(){
	a1 = document.getElementById('celda144').style.background="grey";
}

//banner en verde linma
function comprobar148(){
	a1 = document.getElementById('celda148').style.background="lime";
}
function comprobar149(){
	a1 = document.getElementById('celda149').style.background="lime";
}
function comprobar150(){
	a1 = document.getElementById('celda150').style.background="lime";
}
function comprobar151(){
	a1 = document.getElementById('celda151').style.background="lime";
}
function comprobar152(){
	a1 = document.getElementById('celda152').style.background="lime";
}
function comprobar153(){
	a1 = document.getElementById('celda153').style.background="lime";
}

//parte de software
function comprobar158(){
	a1 = document.getElementById('celda158').style.background="yellow";
}

//parte de css
function comprobar161(){
	a1 = document.getElementById('celda161').style.background="rgba(82, 136, 224 )";
}

//parte de frontend
function comprobar163(){
	a1 = document.getElementById('celda163').style.background="purple";
}

//parte de frame
function comprobar165(){
	a1 = document.getElementById('celda165').style.background="grey";
}

//parte de meta
function comprobar168(){
	a1 = document.getElementById('celda168').style.background="lime";
}
//parte de css
function comprobar183(){
	a1 = document.getElementById('celda183').style.background="rgba(82, 136, 224 )";
}
//parte de frame
function comprobar186(){
	a1 = document.getElementById('celda186').style.background="grey";
}

//parte de meta
function comprobar188(){
	a1 = document.getElementById('celda188').style.background="lime";
}
//parte de figure
function comprobar189(){
	a1 = document.getElementById('celda189').style.background="yellow";
}

//background en brown
function comprobar192(){
	a1 = document.getElementById('celda192').style.background="brown";
}
function comprobar193(){
	a1 = document.getElementById('celda193').style.background="brown";
}
function comprobar194(){
	a1 = document.getElementById('celda194').style.background="brown";
}
function comprobar195(){
	a1 = document.getElementById('celda195').style.background="brown";
}
function comprobar196(){
	a1 = document.getElementById('celda196').style.background="brown";
}
function comprobar197(){
	a1 = document.getElementById('celda197').style.background="brown";
}
function comprobar198(){
	a1 = document.getElementById('celda198').style.background="brown";
}
function comprobar199(){
	a1 = document.getElementById('celda199').style.background="brown";
}
function comprobar200(){
	a1 = document.getElementById('celda200').style.background="brown";
}
function comprobar201(){
	a1 = document.getElementById('celda201').style.background="brown";
}

//parte de frame
function comprobar207(){
	a1 = document.getElementById('celda207').style.background="grey";
}

//parte de meta
function comprobar208(){
	a1 = document.getElementById('celda208').style.background="lime";
}
//parte de figure
function comprobar210(){
	a1 = document.getElementById('celda210').style.background="yellow";
}
//backup en gris
function comprobar215(){
	a1 = document.getElementById('celda215').style.background="grey";
}
function comprobar216(){
	a1 = document.getElementById('celda216').style.background="grey";
}
function comprobar217(){
	a1 = document.getElementById('celda217').style.background="grey";
}
function comprobar218(){
	a1 = document.getElementById('celda218').style.background="grey";
}
function comprobar219(){
	a1 = document.getElementById('celda219').style.background="grey";
}
function comprobar220(){
	a1 = document.getElementById('celda220').style.background="grey";
}

//https en magenta
function comprobar223(){
	a1 = document.getElementById('celda223').style.background="magenta";
}
function comprobar224(){
	a1 = document.getElementById('celda224').style.background="magenta";
}
function comprobar225(){
	a1 = document.getElementById('celda225').style.background="magenta";
}
function comprobar226(){
	a1 = document.getElementById('celda226').style.background="magenta";
}
function comprobar227(){
	a1 = document.getElementById('celda227').style.background="magenta";
}

//parte de meta
function comprobar228(){
	a1 = document.getElementById('celda228').style.background="lime";
}
//parte de figure
function comprobar231(){
	a1 = document.getElementById('celda231').style.background="yellow";
}
//article en magenta
function comprobar232(){
	a1 = document.getElementById('celda232').style.background="magenta";
}
function comprobar233(){
	a1 = document.getElementById('celda233').style.background="magenta";
}
function comprobar234(){
	a1 = document.getElementById('celda234').style.background="magenta";
}
function comprobar235(){
	a1 = document.getElementById('celda235').style.background="magenta";
}
function comprobar236(){
	a1 = document.getElementById('celda236').style.background="magenta";
}
function comprobar237(){
	a1 = document.getElementById('celda237').style.background="magenta";
}
function comprobar238(){
	a1 = document.getElementById('celda238').style.background="magenta";
}

//cookie en azul claro
function comprobar242(){
	a1 = document.getElementById('celda242').style.background="rgba(0, 181, 239)";
}
function comprobar243(){
	a1 = document.getElementById('celda243').style.background="rgba(0, 181, 239)";
}
function comprobar244(){
	a1 = document.getElementById('celda244').style.background="rgba(0, 181, 239)";
}
function comprobar245(){
	a1 = document.getElementById('celda245').style.background="rgba(0, 181, 239)";
}
function comprobar246(){
	a1 = document.getElementById('celda246').style.background="rgba(0, 181, 239)";
}
function comprobar247(){
	a1 = document.getElementById('celda247').style.background="rgba(0, 181, 239)";
}

//parte de figure
function comprobar252(){
	a1 = document.getElementById('celda252').style.background="yellow";
}
//table en color verde militar
function comprobar258(){
	a1 = document.getElementById('celda258').style.background="olive";
}
function comprobar259(){
	a1 = document.getElementById('celda259').style.background="olive";
}
function comprobar260(){
	a1 = document.getElementById('celda260').style.background="olive";
}
function comprobar261(){
	a1 = document.getElementById('celda261').style.background="olive";
}
function comprobar262(){
	a1 = document.getElementById('celda262').style.background="olive";
}

//parte de figure
function comprobar273(){
	a1 = document.getElementById('celda273').style.background="yellow";
}

//copyright en verde aguamarina
function comprobar274(){
	a1 = document.getElementById('celda274').style.background="rgba(0, 239, 94)";
}
function comprobar275(){
	a1 = document.getElementById('celda275').style.background="rgba(0, 239, 94)";
}
function comprobar276(){
	a1 = document.getElementById('celda276').style.background="rgba(0, 239, 94)";
}
function comprobar277(){
	a1 = document.getElementById('celda277').style.background="rgba(0, 239, 94)";
}
function comprobar278(){
	a1 = document.getElementById('celda278').style.background="rgba(0, 239, 94)";
}
function comprobar279(){
	a1 = document.getElementById('celda279').style.background="rgba(0, 239, 94)";
}
function comprobar280(){
	a1 = document.getElementById('celda280').style.background="rgba(0, 239, 94)";
}
function comprobar281(){
	a1 = document.getElementById('celda281').style.background="rgba(0, 239, 94)";
}
function comprobar282(){
	a1 = document.getElementById('celda282').style.background="rgba(0, 239, 94)";
}

//footer en naranjado
function comprobar286(){
	a1 = document.getElementById('celda286').style.background="orange";
}
function comprobar287(){
	a1 = document.getElementById('celda287').style.background="orange";
}
function comprobar288(){
	a1 = document.getElementById('celda288').style.background="orange";
}
function comprobar289(){
	a1 = document.getElementById('celda289').style.background="orange";
}
function comprobar290(){
	a1 = document.getElementById('celda290').style.background="orange";
}
function comprobar291(){
	a1 = document.getElementById('celda291').style.background="orange";
}

//parte de figure
function comprobar293(){
	a1 = document.getElementById('celda293').style.background="yellow";
}